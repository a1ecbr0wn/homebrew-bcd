# Security Policy

## Supported Versions


| Version | Supported          |
| ------- | ------------------ |
| 0.2.x   | :white_check_mark: |
| < 0.2   | :x:                |

## Reporting a Vulnerability

To report a vulnerability, raise an issue.
