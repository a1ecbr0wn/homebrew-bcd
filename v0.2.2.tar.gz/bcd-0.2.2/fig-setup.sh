# see: https://fig.io/docs/guides/autocomplete-for-internal-tools#add-to-ci-recommended

npx @fig/publish-spec --spec-path target/.fig/bcd.ts